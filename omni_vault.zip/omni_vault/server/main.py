
from fastapi import FastAPI, HTTPException, Depends, Header, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
import os, json, pathlib

app = FastAPI(title="Omni Vault", version="0.1.0", description="Spec + files with lock controls")

VAULT_ROOT = pathlib.Path(__file__).resolve().parents[1]
API_SPEC = VAULT_ROOT / "api" / "omni_api.yaml"
DATA_DIR = VAULT_ROOT / "data"
LOCK_FILE = VAULT_ROOT / "lock.config"

OWNER_TOKEN = os.getenv("OMNI_VAULT_OWNER_TOKEN", "CHANGE_ME")
LOCKED_DEFAULT = True

def is_locked():
    if LOCK_FILE.exists():
        try:
            conf = json.loads(LOCK_FILE.read_text())
            return bool(conf.get("locked", True))
        except Exception:
            return True
    return LOCKED_DEFAULT

def require_owner(authorization: str = Header(default="")):
    # Expect "Bearer <token>"
    parts = authorization.split()
    if len(parts) == 2 and parts[0].lower() == "bearer" and parts[1] == OWNER_TOKEN:
        return True
    raise HTTPException(status_code=401, detail="Unauthorized")

@app.get("/health")
def health():
    return {"status": "ok", "locked": is_locked()}

@app.get("/spec", response_class=FileResponse)
def get_spec():
    if not API_SPEC.exists():
        raise HTTPException(status_code=404, detail="Spec not found")
    return FileResponse(API_SPEC)

@app.get("/files")
def list_files():
    files = []
    for p in DATA_DIR.glob("*"):
        if p.is_file():
            files.append({"name": p.name, "size": p.stat().st_size})
    return {"locked": is_locked(), "files": files}

@app.get("/files/{name}", response_class=FileResponse)
def fetch_file(name: str):
    p = DATA_DIR / name
    if not p.exists():
        raise HTTPException(status_code=404, detail="Not found")
    return FileResponse(p)

@app.delete("/files/{name}")
def delete_file(name: str, authorized: bool = Depends(require_owner)):
    # Deletion requires owner token AND vault must be unlocked
    if is_locked():
        raise HTTPException(status_code=423, detail="Vault is locked")
    p = DATA_DIR / name
    if not p.exists():
        raise HTTPException(status_code=404, detail="Not found")
    p.unlink()
    return {"deleted": name}

class LockState(BaseModel):
    locked: bool

@app.post("/lock")
def set_lock(state: LockState, authorized: bool = Depends(require_owner)):
    # Only owner can change lock state
    try:
        (LOCK_FILE).write_text(json.dumps({"locked": state.locked}))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"locked": state.locked}

# Nice-to-have: owner-only upload (still blocked if locked)
from fastapi import UploadFile, File
@app.post("/upload")
def upload(file: UploadFile = File(...), authorized: bool = Depends(require_owner)):
    if is_locked():
        raise HTTPException(status_code=423, detail="Vault is locked")
    dest = DATA_DIR / file.filename
    with open(dest, "wb") as f:
        f.write(file.file.read())
    return {"uploaded": file.filename, "size": dest.stat().st_size}
