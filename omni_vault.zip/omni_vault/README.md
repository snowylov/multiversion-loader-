
# Omni Vault (Spec + Files, Locked by Default)

This package ships your OpenAPI spec and artifacts in a local "vault" with a FastAPI server.
It also includes Terraform to provision an **immutable S3 vault** (Object Lock) where files cannot
be deleted except by you, with MFA. Local server enforces a lock so only you can delete/modify
when *you* unlock it.

## Local usage (demo, not permanent storage)
```bash
export OMNI_VAULT_OWNER_TOKEN="REPLACE_WITH_LONG_RANDOM"
./scripts/run_local.sh
# Server at http://localhost:8080
curl http://localhost:8080/health
curl http://localhost:8080/spec --output omni_api.yaml
curl -H "Authorization: Bearer $OMNI_VAULT_OWNER_TOKEN" -X POST http://localhost:8080/lock -H 'Content-Type: application/json' -d '{"locked": false}'
# upload then re-lock
```

## API endpoints
- GET /health
- GET /spec
- GET /files
- GET /files/{name}
- POST /upload            (owner-only; blocked when locked)
- POST /lock              (owner-only)
- DELETE /files/{name}    (owner-only; blocked when locked)

## Cloud immutability (recommended)
1. Install Terraform and AWS CLI with an account that can enable **S3 Object Lock**.
2. In `infra/terraform/`, run:
```bash
terraform init
terraform apply -var="region=us-east-1" -var="bucket_name=<unique-name>" -var="owner_arn=<your-iam-user-arn>"
```
3. Upload artifacts with bucket lock enforced. Deletes are denied for everyone except your IAM ARN,
and even then require MFA and (if in governance mode) bypass permission.

## Security notes
- Set a long random `OMNI_VAULT_OWNER_TOKEN`.
- The local server is not a substitute for WORM storage. Use the provided Terraform to get true immutability.
- Keep backups (e.g., Git with branch protections + signed tags).

## Contents
- `api/omni_api.yaml` — your OpenAPI spec.
- `data/` — your KG, simulation, results, canonical record.
- `server/` — FastAPI app with lock controls.
- `infra/terraform/` — S3 Object Lock bucket and policy.
- `scripts/` — run script.
