
#!/usr/bin/env bash
set -euo pipefail
export OMNI_VAULT_OWNER_TOKEN="${OMNI_VAULT_OWNER_TOKEN:-CHANGE_ME}"
python -m pip install fastapi uvicorn pydantic
python -m uvicorn server.main:app --host 0.0.0.0 --port 8080
