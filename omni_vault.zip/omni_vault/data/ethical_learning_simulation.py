
import random, csv

def run(rounds=36, seed=7):
    random.seed(seed)
    like_map = {"low": 0.33, "medium": 0.66, "high": 1.0}
    imp_map = {"low": 0.33, "medium": 0.66, "high": 1.0}
    base_like = like_map.get("medium", 0.5)
    base_imp = imp_map.get("high", 0.5)
    baseline_risk = (base_like + base_imp) / 2.0
    control_effectiveness = 0.25
    learning_gain_rate = 0.05

    normalizedRisk = baseline_risk
    learningLevel = 0.0

    rows = []
    for t in range(rounds):
        noise = random.uniform(-0.05, 0.05)
        normalizedRisk = max(0.0, normalizedRisk * (1 - control_effectiveness) + noise)
        learning_delta = learning_gain_rate * (1 + max(0, 0.5 - normalizedRisk))
        learningLevel = min(1.0, max(0.0, learningLevel + learning_delta))
        harm_adjusted_gain = learning_delta * (1 - max(0.0, min(1.0, normalizedRisk)))
        rows.append([t, normalizedRisk, learning_delta, learningLevel, harm_adjusted_gain])

    with open("sim_results.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["round","normalizedRisk","learningDelta","learningLevel","harmAdjustedGain"])
        w.writerows(rows)

if __name__ == "__main__":
    run()
