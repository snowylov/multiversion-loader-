#!/usr/bin/env bash
set -euo pipefail

# Build a release manifest with file hashes for api/ and data/
OUT="RELEASE_MANIFEST.md"
echo "# Release Manifest" > "${OUT}"
date -u +"Generated at: %Y-%m-%dT%H:%M:%SZ" >> "${OUT}"
echo >> "${OUT}"
echo "## Files & SHA-256" >> "${OUT}"
echo >> "${OUT}"

hash_file() {
  local f="$1"
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$f" | awk '{print $1}'
  else
    sha256sum "$f" | awk '{print $1}'
  fi
}

for dir in api data; do
  if [[ -d "$dir" ]]; then
    echo "### $dir/" >> "${OUT}"
    while IFS= read -r -d '' f; do
      hash=$(hash_file "$f")
      echo "- \`$f\` — \`$hash\`" >> "${OUT}"
    done < <(find "$dir" -type f -print0 | sort -z)
    echo >> "${OUT}"
  fi
done

echo "[INFO] Wrote ${OUT}"
