#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <s3-bucket>"
  exit 1
fi

BUCKET="$1"

# Sync API and data. The bucket has Object Lock default retention via Terraform.
# We set metadata and cache headers for sane defaults.
aws s3 cp api/ "s3://${BUCKET}/api/" --recursive \
  --metadata "deployed-by=github-actions" \
  --cache-control "no-cache"

aws s3 cp data/ "s3://${BUCKET}/data/" --recursive \
  --metadata "deployed-by=github-actions" \
  --cache-control "no-cache"

# Upload release manifest if present
if [[ -f "RELEASE_MANIFEST.md" ]]; then
  aws s3 cp RELEASE_MANIFEST.md "s3://${BUCKET}/manifests/RELEASE_MANIFEST.md" \
    --metadata "deployed-by=github-actions"
fi

echo "[INFO] Sync complete to s3://${BUCKET}"
