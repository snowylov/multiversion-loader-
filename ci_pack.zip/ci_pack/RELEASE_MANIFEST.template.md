# Release Manifest

Generated at: <CI sets timestamp>
Deployed by: GitHub Actions

## Files & SHA-256

(Generated automatically by scripts/package_release.sh)
